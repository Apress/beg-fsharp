﻿#light
namespace Strangelights.Extensions
#if INTERACTIVE
#r "System.Threading"
#r "System.Core"
#endif
open System
open System.Linq

module PSeq =
    // Import some stuff from PLink
    let asParallel list: IParallelEnumerable<_> = ParallelQuery.AsParallel(list)
    let map f list = ParallelEnumerable.Select(asParallel list, new Func<_, _>(f))
    let reduce f list = ParallelEnumerable.Aggregate(asParallel list, new Func<_, _, _>(f))
    let fold f acc list = ParallelEnumerable.Aggregate(asParallel list, acc, new Func<_, _, _>(f))