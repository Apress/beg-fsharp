﻿#light
#time
open System.Diagnostics
open Strangelights.Extensions
//let testMap items ops =
//    Seq.map (fun _ -> for x in 0 .. ops do x + 1 |> ignore) (seq { 1 .. items })
//    |> Seq.iter (fun _ -> ())

let samples = 5
let runs = 100

let harness f items ops =
    let res =
        seq { for _ in 1 .. samples do
                let clock = new Stopwatch()
                clock.Start()
                for _ in 1 .. runs do 
                    f items ops
                clock.Stop()
                yield clock.ElapsedMilliseconds }
    let avg = float (Seq.reduce (+) res) / (float samples)
    printf "Items %i, Ops %i," items ops
    Seq.iter (printf "%i,") res
    printfn "%f" avg



let addSlowly x =
    Seq.fold (fun acc _ -> acc + 1) 0 (seq { 1 .. x })

let testMap items ops =
    Seq.map (fun _ -> addSlowly ops) (seq { 1 .. items })
    |> Seq.iter (fun _ -> ())

let testPMap items ops =
    PSeq.map (fun _ -> addSlowly ops) (seq { 1 .. items })
    |> Seq.iter (fun _ -> ())

let itemsList = [ 10; 100; 1000 ]
let opsList = [ 1; 10; 100; 1000 ]

for items in itemsList do
    for ops in opsList do
        harness testMap items ops

for items in itemsList do
    for ops in opsList do
        harness testPMap items ops

//testMap 5000 1      // 00.006
//testMap 5000 10     // 00.016
//testMap 5000 100    // 00.098
//testMap 5000 1000   // 00.940
//testMap 5000 10000  // 09.744
//testMap 10000 1
//testMap 10000 10    // 00.030
//testMap 10000 100   // 00.195
//testMap 10000 1000  // 00.189
//testMap 10000 10000 // 18.185
//testMap 20000 1     // 00.025
//testMap 20000 10    // 00.057
//testMap 20000 100   // 00.374
//testMap 20000 1000  // 03.629
//testMap 20000 10000 // 40.456
//testMap 100000 1    // 00.113
//
//testPMap 5000 1      // 00.011
//testPMap 5000 10     // 00.011
//testPMap 5000 100    // 00.049
//testPMap 5000 1000   // 00.700
//testPMap 5000 10000  // 06.131
//testPMap 10000 1     // 00.007
//testPMap 10000 10
//testPMap 10000 100   // 00.131
//testPMap 10000 1000  // 01.036
//testPMap 10000 10000 // 11.020
//testPMap 20000 1     // 00.016
//testPMap 20000 10
//testPMap 20000 100   // 00.203
//testPMap 20000 1000  // 01.967
//testPMap 20000 10000 // 18.234
//testPMap 100000 1    // 00.071


let test = seq { yield 3; yield 3; yield 6; yield 3; yield 3; }

let test'() =
    let avg = float (Seq.reduce (+) test) / (float runs)
    Seq.iter (printf "%i,") test
    printfn "%f" avg
